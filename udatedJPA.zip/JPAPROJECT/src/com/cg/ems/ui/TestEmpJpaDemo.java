package com.cg.ems.ui;

import java.util.ArrayList;

import com.cg.ems.dto.Employee;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class TestEmpJpaDemo {

	public static void main(String[] args) {
		EmployeeService  empSer=new EmployeeServiceImpl();
        Employee e1=new Employee();
       
        Employee e2=new Employee();
       /* e1.setEmpName("Tanu");
        e1.setEmpSal(1000.0F);
        e2.setEmpName("Tanya");
        e2.setEmpSal(2000.0F);
        Employee ee1=empSer.addEmp(e1);
        Employee ee2=empSer.addEmp(e2);
       
        System.out.println(ee1+"\n"+ee2+"\n");
       Employee ee= empSer.getEmpbyId(445);
        System.out.println(ee);*/
        System.out.println("Fetch all records");
        ArrayList<Employee> eList=empSer.fetchAll();
        for(Employee tempE:eList)
        {
        	System.out.println(tempE.getEmpId()+"\t"+tempE.getEmpName()+"\t"+tempE.getEmpSal());
        }
        Employee del=empSer.deleteEmp(445);
         System.out.println("deleted"+del);
         
         Employee updated=empSer.updateEmp(41,"kaushal",90000);
         System.out.println("updated... data for:"+updated.getEmpId());
	}

}
