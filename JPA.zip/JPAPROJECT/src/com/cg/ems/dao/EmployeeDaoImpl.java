package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.dto.Employee;
import com.cg.ems.util.JPAUtil;

public class EmployeeDaoImpl implements EmployeeDao {
	EntityManager em=null;
	EntityTransaction  entityTran=null;
	public EmployeeDaoImpl() {
		em=JPAUtil.getEntityManager();
		entityTran=em.getTransaction();
	}

	@Override
	public Employee addEmp(Employee emp) {
		entityTran.begin();
		em.persist(emp);
		entityTran.commit();
		return emp;
		
		
	}

	@Override
	public ArrayList<Employee> fetchAll() {
		
		return null;
	}

	@Override
	public Employee deleteEmp(int empId) {
		
		return null;
	}

	@Override
	public Employee getEmpbyId(int empId) {
		
		return null;
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		
		return null;
	}

}
