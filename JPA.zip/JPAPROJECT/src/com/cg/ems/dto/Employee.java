package com.cg.ems.dto;


import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity	
@Table(name="emp1")
public class Employee {
	@Id
	@Column(name="emp_id",length=20)
		private int empId;
	@Column(name="emp_name",length=30)
	private String  empName;
	 @Column(name="emp_sal",length=10)
	private float  empSal;
	
    @Transient
	private LocalDate empDoj;

	
 public Employee() {
		super();
	}
@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empDoj=" + empDoj + "]";
	}
public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public LocalDate getEmpDoj() {
		return empDoj;
	}
	public void setEmpDoj(LocalDate empDoj) {
		this.empDoj = empDoj;
	}
public Employee(int empId, String empName, float empSal, LocalDate empDoj) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDoj = empDoj;
	}

}
