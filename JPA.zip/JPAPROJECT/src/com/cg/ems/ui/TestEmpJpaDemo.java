package com.cg.ems.ui;

import com.cg.ems.dto.Employee;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class TestEmpJpaDemo {

	public static void main(String[] args) {
		EmployeeService  empSer=new EmployeeServiceImpl();
        Employee e1=new Employee(444,"Tanu sharma",5400.0F,null);
        Employee e2=new Employee(445,"Vikash Agarwal",4500.0F,null);
        Employee e3=new Employee(446,"Tanu gupta",1400.0F,null);
        Employee ee1=empSer.addEmp(e1);
        Employee ee2=empSer.addEmp(e2);
        Employee ee3=empSer.addEmp(e3);
        System.out.println(ee1+"\n"+ee2+"\n"+ee3);
	}

}
